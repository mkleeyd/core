package management.academic.entity;

public enum Gender {
    MAN, WOMAN
}/////
